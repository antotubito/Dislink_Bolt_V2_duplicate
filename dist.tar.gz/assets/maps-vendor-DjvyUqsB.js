import"./capacitor-vendor-BdnFYN1K.js";
